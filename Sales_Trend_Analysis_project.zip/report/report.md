# Sales Trend Analysis — Report

**Objective:** Analyze monthly revenue and order volume using SQL aggregations.

- Rows (orders): 10,565
- Date range: 2023-01-01 02:25:00 to 2024-12-31 23:26:00

## SQL used

```sql
-- analysis.sql
SELECT
  STRFTIME('%Y', order_date) AS year,
  STRFTIME('%m', order_date) AS month,
  SUM(amount) AS monthly_revenue,
  COUNT(*) AS order_volume,
  ROUND(AVG(amount),2) AS avg_order_value
FROM online_sales
GROUP BY year, month
ORDER BY year, month;

```

## Visuals

![Monthly Revenue](../screenshots/monthly_revenue_trend.png)

![Monthly Order Volume](../screenshots/monthly_order_volume.png)

![Avg Order Value](../screenshots/monthly_avg_order_value.png)


## Top 3 months by revenue

|   year |   month |   monthly_revenue |   order_volume |   avg_order_value | year_month   |
|-------:|--------:|------------------:|---------------:|------------------:|:-------------|
|   2023 |      12 |           62346.9 |            861 |             72.41 | 2023-12      |
|   2023 |      11 |           53502.5 |            759 |             70.49 | 2023-11      |
|   2024 |      12 |           51682.4 |            715 |             72.28 | 2024-12      |

## Observations
- Seasonality: peaks during Nov/Dec.
- Monitor AOV changes and promotions.
