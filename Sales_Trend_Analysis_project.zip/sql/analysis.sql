-- analysis.sql
SELECT
  STRFTIME('%Y', order_date) AS year,
  STRFTIME('%m', order_date) AS month,
  SUM(amount) AS monthly_revenue,
  COUNT(*) AS order_volume,
  ROUND(AVG(amount),2) AS avg_order_value
FROM online_sales
GROUP BY year, month
ORDER BY year, month;
